create database db_aluno
